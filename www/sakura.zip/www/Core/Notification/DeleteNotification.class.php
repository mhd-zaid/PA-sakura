<?php
namespace App\Core\Notification;

use App\Core\Observer;

//Observer
 class DeleteNotification implements Observer{
    public function alert(){
    }
 }
<nav id="parameters-nav">
    <h1 id="menu-title">Paramètres</h1>
    <div class="container">
        <h1>Général</h1>
		<ul>
            <li class="choices-parameters"><a href="/parametres-gestion-compte"><img src="Public/img/Back/account1.svg" alt="Account">Gestion du compte</a></li>
            <li class="choices-parameters"><a href="/parametres-users"><img src="Public/img/Back/site1.svg" alt="Utilisateurs">Gestions des utilisateurs</a></li>
            <li class="choices-parameters"><a href="/parametres"><img src="Public/img/Back/lang1.svg" alt="Language">Langue</a></li>
            <li class="choices-parameters"><a href="/home"><img src="Public/img/Back/security1.svg" alt="Shield">Sécurité</a></li>
		</ul>
        <h1>Communication</h1>
        <ul>
            <li class="choices-parameters"><a href="/parametres"><img src="Public/img/Back/notification1.svg" alt="Notification"><button class="cta-button btn--white-rounded">Notification</button></a></li>
        </ul>
        <h1>Aide</h1>
        <ul>
            <li class="choices-parameters"><a href="/parametres"><img src="Public/img/Back/help1.svg" alt="Support">Support</a></li>
            <li class="choices-parameters"><a href="/parametres"><img src="Public/img/Back/cgu1.svg" alt="CGU">CGU</a></li>
        </ul>
	</div>
</nav>
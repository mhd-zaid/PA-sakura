<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Page not found">
    <title>Page Not found</title>
    <link rel="stylesheet" href="../Public/css/main.css">
    <script type="text/javascript" src="../Public/js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="../Public/js/site.js"></script>
</head>

<body class="sk-body-front body">
    <main>
        <p class="text-404">HTTP: <span class="nb-404">404</span></p>
        <p class="text-404">page not found</p>
    </main>
</body>

</html>
<div class="container relative">
	<section class="relative content-page">

		<div class="row body-item">
			<h1>
				<?php $mainPage['Title']; ?>
			</h1>
		</div>

		<div class="row">
			<?= $mainPage['Content']; ?>
		</div>
	</section>
</div>
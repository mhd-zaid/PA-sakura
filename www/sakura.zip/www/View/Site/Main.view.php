<h1>
<?php 
    echo $page['Title'];
?>
</h1>

<?php 
   echo  $page['Content'];
?>
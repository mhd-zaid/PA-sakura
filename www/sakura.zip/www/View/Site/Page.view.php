<section class="relative content-page">
    
    <div class="row body-item">
        <h1>
            <?= $the_page['Title']; ?>
        </h1>
    </div>

    <div>
        <?= $the_page['Content']; ?>
    </div>
</section>
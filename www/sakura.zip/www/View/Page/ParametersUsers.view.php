<div id="parameter-users" class="container-fluid ">
    <section class="grid">
        <div class="row parameter-header">
                <h1 class="h1-section-back">Paramètres&nbsp;&nbsp;&nbsp;>&nbsp;&nbsp;&nbsp;Gestion des utilisateurs </h1>
        </div>
        <div class="row">
            <div class="col">
                <a href="/parametres-add-user" class="cta-button btn--pink">Ajouter</a>
            </div>
        </div>
    </section>

    <section id="parameter-usersdt" class="grid grid-rounded">
        <div class="row">
            <div class="col col-12">
                <table id="table_users" class="display hover order-column">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Id</th>
                            <th>Prénom</th>
                            <th>Nom</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </section>
</div>
<section class="grid">
        <div class="row page-header">
            <div class="col">
            <h1 class="h1-section-back">Article</h1>
            <h1 class="h-section-back">Gérer les articles de vos sites ici</h1>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <a href="/article-add" class="cta-button btn--pink">Ajouter</a>
            <a href="/category" class="cta-button btn--pink">Catégories</a>
        </div>
    </div>
</section>

<section class="grid grid-rounded">
    <div class="row">
        <div class="col col-12">
        <table id="table_articles" class="display hover order-column">
        <thead>
            <tr>
                <th></th>
                <th>Id</th>
                <th>Titre</th>
                <th>Auteur</th>
                <th>Publié</th>
            </tr>
        </thead>
    </table>
        </div>
    </div>
</section>
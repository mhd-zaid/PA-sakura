<section class="grid">
        <div class="row page-header">
            <div class="col">
            <h1 class="h1-section-back">Commentaire</h1>
            <h1 class="h-section-back">Status des commentaires</h1>
        </div>
    </div>
    <div class="row">
        <div class="col col-2 flex-col flex-col-center"><a href="/commentaire-mots-bannis" id="comment_banned"> <p class="filter">Mot bannis</p></a></div>

    </div>
</section>

<!-- TODO : Modifier le format de l'heure 
-->
<section class="grid grid-rounded">
    <div class="row">
        <div class="col col-12 col-xs-">
        <table id="table_comments" class="display hover order-column">
        <thead>
            <tr>
                <th>Id</th>
                <th>Author</th>
                <th>Content</th>
                <th>Email</th>
                <th>Status</th>
                <th>Date Created</th>
                <th>Article Related</th>
                <th>Nombre de signalement</th>
                <th>Approuve</th>
                <th>Unapprove</th>
                <th>Delete</th>
            </tr>
        </thead>
        
    </table>
        </div>
    </div>
</section>
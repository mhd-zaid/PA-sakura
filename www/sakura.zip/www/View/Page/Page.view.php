<section class="grid">
        <div class="row page-header">
            <div class="col">
            <h1 class="h1-section-back">Liste des pages</h1>
            <h1 class="h-section-back">Gérer les pages de vos sites ici</h1>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <a href="/page-add" class="cta-button btn--pink">Ajouter</a>
        </div>
    </div>
</section>

<section class="grid grid-rounded">
    <div class="row">
        <div class="col col-12 col-xs-">
        <table id="table_pages" class="display hover order-column">
        <thead>
            <tr>
                <th></th>
                <th>Id</th>
                <th>Title</th>
                <th>Auteur</th>
                <th>Publié</th>
            </tr>
        </thead>
        
    </table>
        </div>
    </div>
</section>
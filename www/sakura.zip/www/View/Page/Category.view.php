<section class="grid">
        <div class="row page-header">
            <div class="col">
            <h1 class="h1-section-back">Catégories</h1>
            <h1 class="h-section-back">Gérer vos catégories ici</h1>
            <div class="row">
        <div class="col">
            <a href="/category-add" class="cta-button btn--pink">Ajouter</a>
        </div>
    </div> 
        </div>
        
    </div>
</section>

<section class="grid grid-rounded">
    <div class="row">
        <div class="col col-12">
        <table id="table_categorys" class="display hover order-column">
        <thead>
            <tr>
                <th></th>
                <th>Id</th>
                <th>Title</th>
            </tr>
        </thead>
    </table>
        </div>
    </div>
</section>
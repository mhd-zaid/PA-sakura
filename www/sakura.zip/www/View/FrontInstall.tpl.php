<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Installation</title>
	<meta name="description" content="Ceci est ma page">
	<link rel="stylesheet" type="text/css" href="Public/css/main.css">        
</head>
<body>
	<main id="main-front">

	<?php require $this->view; ?>

	</main>
</body>
</html>
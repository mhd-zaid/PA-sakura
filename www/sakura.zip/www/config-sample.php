<?php

define("DB_HOST","db_host");
define("DB_NAME","db_name");
define("DB_USER","db_user");
define("DB_PASSWD","db_passwd");
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : database
-- Généré le : jeu. 05 jan. 2023 à 22:40
-- Version du serveur : 5.7.39
-- Version de PHP : 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `sakura`
--

-- --------------------------------------------------------

--
-- Structure de la table `sakura_apparence`
--

CREATE TABLE `sakura_apparence` (
  `Id` int(11) NOT NULL,
  `Css` longtext NOT NULL,
  `Active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sakura_article`
--

CREATE TABLE `sakura_article` (
  `Id` int(11) NOT NULL,
  `Content` text,
  `Slug` varchar(50) DEFAULT NULL,
  `User_Id` int(11) NOT NULL,
  `Image_Name` varchar(50) NOT NULL,
  `Active` int(11) NOT NULL DEFAULT '0',
  `Description` varchar(255) DEFAULT NULL,
  `Rewrite_Url` int(11) NOT NULL DEFAULT '1',
  `Title` varchar(255) DEFAULT NULL,
  `categories` varchar(255) DEFAULT NULL,
  `Date_Created` datetime DEFAULT CURRENT_TIMESTAMP,
  `Date_Updated` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sakura_category`
--

CREATE TABLE `sakura_category` (
  `Id` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sakura_comment`
--

CREATE TABLE `sakura_comment` (
  `Id` int(11) NOT NULL,
  `Content` longtext,
  `Status` varchar(255) NOT NULL,
  `Comment_Post_Id` int(11) NOT NULL,
  `Author` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Date_Created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nombre_signalement` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sakura_menu`
--

CREATE TABLE `sakura_menu` (
  `Id` int(11) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `Content` varchar(500) NOT NULL,
  `Active` int(11) NOT NULL DEFAULT '0',
  `Main` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sakura_page`
--

CREATE TABLE `sakura_page` (
  `Id` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Content` text,
  `Active` tinyint(1) NOT NULL,
  `User_Id` int(11) DEFAULT NULL,
  `Description` text,
  `Main` int(11) DEFAULT NULL,
  `Slug` varchar(255) DEFAULT NULL,
  `Rewrite_Url` varchar(10) DEFAULT NULL,
  `Date_Created` datetime DEFAULT CURRENT_TIMESTAMP,
  `Date_Updated` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sakura_site`
--

CREATE TABLE `sakura_site` (
  `Id` int(11) NOT NULL,
  `Logo` varchar(255) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Number` varchar(20) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sakura_stats`
--

CREATE TABLE `sakura_stats` (
  `Id` int(11) NOT NULL,
  `Session` varchar(255) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `sakura_user`
--

CREATE TABLE `sakura_user` (
  `Id` int(11) NOT NULL,
  `Firstname` varchar(25) DEFAULT NULL,
  `Lastname` varchar(70) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Status` tinyint(3) NOT NULL DEFAULT '0',
  `Role` tinyint(3) NOT NULL DEFAULT '1',
  `Token` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `sakura_apparence`
--
ALTER TABLE `sakura_apparence`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `sakura_article`
--
ALTER TABLE `sakura_article`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `sakura_category`
--
ALTER TABLE `sakura_category`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `sakura_comment`
--
ALTER TABLE `sakura_comment`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `sakura_menu`
--
ALTER TABLE `sakura_menu`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `sakura_page`
--
ALTER TABLE `sakura_page`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `sakura_site`
--
ALTER TABLE `sakura_site`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `sakura_stats`
--
ALTER TABLE `sakura_stats`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `sakura_user`
--
ALTER TABLE `sakura_user`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `sakura_apparence`
--
ALTER TABLE `sakura_apparence`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `sakura_article`
--
ALTER TABLE `sakura_article`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `sakura_category`
--
ALTER TABLE `sakura_category`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `sakura_comment`
--
ALTER TABLE `sakura_comment`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `sakura_menu`
--
ALTER TABLE `sakura_menu`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `sakura_page`
--
ALTER TABLE `sakura_page`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `sakura_site`
--
ALTER TABLE `sakura_site`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `sakura_stats`
--
ALTER TABLE `sakura_stats`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `sakura_user`
--
ALTER TABLE `sakura_user`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
